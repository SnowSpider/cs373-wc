Course Name: CS373
Unique: 91055

First Name: Wonjun
Last Name: Lee
EID: WL4337
E-mail: SnowSpider221@gmail.com
Estimated number of hours: 40
Actual    number of hours: 20

Turnin CS Username:     wlee
GitHub ID:              SnowSpider
GitHub Repository Name: cs373-wc
Google App Engine URL:  wlee-cs373-wc.appspot.com

<repeat for each group member>

Group Member First Name: Daniel
Group Member Last Name:  Moreno
Group Member EID:        drm2472
Group Member E-mail:     longhorndrm@gmail.com
Group Member Rating:           Very Good
Group Member Point Adjustment: 0

Group Member First Name: Sogol
Group Member Last Name:  Moshtaghi
Group Member EID:        sm38384
Group Member E-mail:     sogol@utexas.com
Group Member Rating:           Satisfactory
Group Member Point Adjustment: 0

Group Member First Name: Tony
Group Member Last Name:  Santi
Group Member EID:        ags693
Group Member E-mail:     platypustony@live.com
Group Member Rating:           Excellent
Group Member Point Adjustment: 0

Group Member First Name: Diane
Group Member Last Name:  Lee
Group Member EID:        dyl228
Group Member E-mail:     dlee198@gmail.com
Group Member Rating:           Very Good
Group Member Point Adjustment: 0


Comments:

--------------------
Group Member Ratings
--------------------

Excellent: consistently went above and beyond; tutored partner; carried more than her fair share of the load.

Very Good: consistently did what she was supposed to do; very well prepared and cooperative.

Satisfactory: usually did what she was supposed to do; minimally prepared and cooperative.

Marginal: sometimes failed to show up; rarely prepared.

Deficient: often failed to show up; rarely prepared.

Unsatisfactory: consistently failed to show up; unprepared.

Superficial: practically no participation.

No Show: no participation at all.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
