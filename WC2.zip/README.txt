Course Name: CS373
Unique: 91055

First Name: Antony
Last Name: Santi
EID: ags693
E-mail: lordtonysama@gmail.com
Estimated number of hours: 25
Actual    number of hours: 20

Turnin CS Username:     lordtony
GitHub ID:              SnowSpider
GitHub Repository Name: cs373-wc
Google App Engine URL:  wlee-cs373-wc.appspot.com

Group Member First Name: Diane
Group Member Last Name: Lee
Group Member EID: dyl228
Group Member E-mail: leed@utexas.edu
Group Member Rating: Excellent
Group Member Point Adjustment: 0

Group Member First Name: Wonjun
Group Member Last Name: Lee
Group Member EID: wl4337
Group Member E-mail: SnowSpider221@gmail.com
Group Member Rating: Excellent
Group Member Point Adjustment: 0

Group Member First Name: Daniel
Group Member Last Name: Moreno
Group Member EID: drm2472
Group Member E-mail: longhorndrm@gmail.com
Group Member Rating: Excellent
Group Member Point Adjustment: 0

Group Member First Name: Sogol
Group Member Last Name: Moshtaghi
Group Member EID: sm38484
Group Member E-mail: SogolMoshtaghi@utexas.edu
Group Member Rating: Excellent
Group Member Point Adjustment: 0

Comments: Once again, I was given a good team to work with.

--------------------
Group Member Ratings
--------------------

Excellent: consistently went above and beyond; tutored partner; carried more than her fair share of the load.

Very Good: consistently did what she was supposed to do; very well prepared and cooperative.

Satisfactory: usually did what she was supposed to do; minimally prepared and cooperative.

Marginal: sometimes failed to show up; rarely prepared.

Deficient: often failed to show up; rarely prepared.

Unsatisfactory: consistently failed to show up; unprepared.

Superficial: practically no participation.

No Show: no participation at all.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.

